
__all__ = []

class Fog:
    pass
