
__all__ = []

class Biome:
    pass
