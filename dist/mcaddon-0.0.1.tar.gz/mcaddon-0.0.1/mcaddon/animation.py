
__all__ = []

class Animation:
    pass
