
__all__ = []

class Recipe:
    pass
