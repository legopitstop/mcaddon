
from .util import Saveable

# TODO
class LootTable(Saveable):
    ...