from mcaddon import CameraPreset

cam = CameraPreset("test:camera", rot_y=90)

cam.save("build/")
