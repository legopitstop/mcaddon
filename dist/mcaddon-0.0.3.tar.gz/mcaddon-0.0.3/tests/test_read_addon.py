from mcaddon import Addon

addon = Addon.open("build/addon")
print(addon.packs)
