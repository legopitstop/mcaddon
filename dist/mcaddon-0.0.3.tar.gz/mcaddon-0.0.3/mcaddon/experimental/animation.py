class Animation:
    pass
