class TextureSet:
    pass
