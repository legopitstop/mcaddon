class Piece:
    pass
