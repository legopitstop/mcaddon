class Fog:
    pass
