class Particle:
    pass
