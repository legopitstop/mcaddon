class Biome:
    pass
