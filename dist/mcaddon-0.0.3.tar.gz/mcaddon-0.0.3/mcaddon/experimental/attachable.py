class Attachable:
    pass
