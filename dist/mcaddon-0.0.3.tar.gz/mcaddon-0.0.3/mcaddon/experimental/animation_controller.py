class AnimationController:
    pass
