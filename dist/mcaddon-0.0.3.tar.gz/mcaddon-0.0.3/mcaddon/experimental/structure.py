class Structure:
    pass
