class SpawnRule:
    pass
